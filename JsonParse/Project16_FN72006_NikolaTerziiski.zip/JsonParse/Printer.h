#pragma once
#include <string>
class Printer {
public:
	const std::string helpInformation = "Commands: \n -open \" path \" - opening file by giving valid path. \n -close - closing the current element. \n -help - printing the current window \n -exit - Closing the whole program. \n";;
	Printer();

};