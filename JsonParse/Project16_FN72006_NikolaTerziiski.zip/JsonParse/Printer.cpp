#include "Printer.h"

Printer::Printer()
{}
